<?php declare(strict_types=1);

namespace PhpParser;

class ConstExprEvaluationException extends \Exception {
}
