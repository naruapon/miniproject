<?php declare(strict_types=1);

namespace PhpParser\Node\Stmt;

use PhpParser\Node\PropertyItem;

require __DIR__ . '/../PropertyItem.php';

if (false) {
    // For classmap-authoritative support.
    class PropertyProperty extends PropertyItem {
    }
}
